  //clase que tiene la exepcion para el manejo de heaps
  public class HeapExcepcion extends RuntimeException {
    
    public HeapExcepcion(){
    };
    public HeapExcepcion(String s){
      super(s);
      }
    }
