  //clase que tiene la exepcion para el manejo de grafos
  public class GrafoExcepcion extends RuntimeException {
    
    public GrafoExcepcion(){
    };
    public GrafoExcepcion(String s){
      super(s);
      }
    }
