// First program
// MW, 5/1/10

public class FirstProgram
{
    public static void main( String [ ] args )
    {
        System.out.println( "Is there anybody out there?" );
    }
}