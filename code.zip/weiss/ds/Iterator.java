package weiss.ds;

public interface Iterator
{
    boolean hasNext( );
    Object next( );
}
