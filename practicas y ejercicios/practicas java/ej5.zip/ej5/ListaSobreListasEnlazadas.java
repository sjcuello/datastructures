
public class ListaSobreListasEnlazadas implements Lista {

    private Nodo head;                       
    private int numItems;                    

    public ListaSobreListasEnlazadas() {

        head = null;
        numItems = 0;

    } 

    public boolean esVacia() {

        // TODO (Implementar)
        return false;

    } 

    public int longitud() {

        // TODO (Implementar)

        return 0;
    } 

    public void vaciar() {

        // TODO (Implementar)
    }

    public void insertar(int index, Object item) {

        // TODO (Implementar) 

    } 

    // insertar item en la cabeza de la lista    
    public void insertar(Object item) {

        Nodo nuevoNodo = new Nodo(item);
        nuevoNodo.cambiarSiguiente(head);
        head = nuevoNodo; 
        numItems = numItems + 1;

    } 

    public void eliminar(int index){

        // TODO (Implementar)

    } 

    public Object obtener(int index)  {
        Object retorno = null; 
        Nodo nodo = head; 
        for (int i=0; i<index && nodo != null ;i++ ) {
            nodo = nodo.obtenerSiguiente();	    		             
        }   
        if (nodo!=null) {
            retorno = nodo.obtenerItem();
        } 
        return retorno;        
    } 

    public String toString() {

        // TODO (Implementar)

        return null;
    }

}
