
public class Main {
    
    public static void main(String args[]) {

        Catalogo c = new Catalogo();

        // TODO: Crear 3 libros y agregarlos al catalogo.

        c.mostrar();

        // TODO: usar buscarPorTitulo para buscar un libro que exista en el catalogo c y otro que no.
   }


}
