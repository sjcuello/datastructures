import java.io.IOException;

public class Main {
    
    public static void main(String args[]) throws IOException {

        Libro l1 = new Libro("The Lord of the Rings", "J. R. R. Tolkien", 1000);
        Libro l2 = new Libro("Harry Potter", "J. K. Rowling", 600);
        Catalogo c1 = new Catalogo();
        c1.agregarLibro(l1);
        c1.agregarLibro(l2);
        Catalogo c2 = c1.copy();
        
        System.out.println("Mostrando libros por primera vez...");
        System.out.println("Catalogo 1:");
        c1.mostrar();
        System.out.println("Catalogo 2:");
        c2.mostrar();

        System.in.read();

        System.out.println("Mostrando libros por segunda vez...");
        c1.quitarLibro(l2);
        System.out.println("Catalogo 1:");
        c1.mostrar();
        System.out.println("Catalogo 2:");
        c2.mostrar();
        
        // TODO: Cual es el problema?
        // TODO: Solucione el problema 
   }

}
